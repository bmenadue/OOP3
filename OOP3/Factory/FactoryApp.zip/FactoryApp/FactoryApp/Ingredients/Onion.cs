﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryApp.Ingredients
{
    public class Onion : Veggies
    {
    }
}
