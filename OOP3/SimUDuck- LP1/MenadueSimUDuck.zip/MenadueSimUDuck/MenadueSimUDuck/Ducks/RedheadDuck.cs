﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenadueSimUDuck
{
    public class RedheadDuck : Duck
    {
        public void Fly()
        {
        }
        public void Quack()
        {
        }

        public override void Display()
        {
            Console.WriteLine("I'm a real Redhead duck");
        }
    }
}
